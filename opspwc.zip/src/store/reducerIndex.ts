import { combineReducers } from "redux";
import { History } from "history";
import { RouterState, connectRouter } from "connected-react-router";
import daySchedule, { DaySchedulesState } from "./daySchedule";

const rootReducer = (history: History) =>
  combineReducers({
    daySchedule,
    router: connectRouter(history)
  });

export default rootReducer;

// export type RootState = ReturnType<typeof rootReducer>
export type RootState = {
  daySchedule: DaySchedulesState;
  router: RouterState;
};
