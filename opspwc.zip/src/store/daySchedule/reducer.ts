import { DaySchedulesState, DayScheduleActions } from "./types";
import { createReducer } from "typesafe-actions";
import {
  GET_DAYSCHEDULE,
  POST_DAYSCHEDULE,
  PUT_DAYSCHEDULE,
  DELETE_DAYSCHEDULE
} from "./actions";
import { dayScheduleData } from "../../components/Calender/dataSet/dataSet";

const testData = dayScheduleData;
// const initialData = [
//   {
//     id: 1,
//     date: '2022-11-01',
//     title: 'item 1'
//   }
// ]

const initialDaySchedulesState: DaySchedulesState = testData;

const daySchedule = createReducer<DaySchedulesState, DayScheduleActions>(
  initialDaySchedulesState,
  {
    [GET_DAYSCHEDULE]: ({}, { payload: daySchedules }) => daySchedules,
    [POST_DAYSCHEDULE]: (state, { payload: daySchedule }) =>
      state.concat({
        id: Math.max(...state.map((schedule) => schedule.id)) + 1,
        date: daySchedule.date,
        title: daySchedule.title
      }),
    [PUT_DAYSCHEDULE]: (state, { payload: daySchedule }) =>
      state.map((schedule) =>
        schedule.id === daySchedule.id ? daySchedule : schedule
      ),
    [DELETE_DAYSCHEDULE]: (state, { payload: id }) =>
      state.filter((schedule) => schedule.id !== id)
  }
);

export default daySchedule;
