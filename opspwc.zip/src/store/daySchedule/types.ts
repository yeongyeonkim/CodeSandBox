import { ActionType } from "typesafe-actions";
import {
  getDaySchedule,
  postDaySchedule,
  putDaySchedule,
  deleteDaySchedule
} from "./actions";

const dayScheduleActions = {
  getDaySchedule,
  postDaySchedule,
  putDaySchedule,
  deleteDaySchedule
};

export type DayScheduleActions = ActionType<typeof dayScheduleActions>;

export type DaySchedule = {
  id: number;
  date: string;
  title: string;
};

export type DaySchedulesState = DaySchedule[];
