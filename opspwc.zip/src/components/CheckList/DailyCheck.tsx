import { useState, useRef } from "react";
import CheckListEditor from "./CheckListEditor";
import DailyCheckList from "./DailyCheckList";
import { dayScheduleData } from "../Calender/dataSet/dataSet";

const DailyCheck = () => {
  // const testData = dayScheduleData;
  // return (
  //   <div className="DailyCheck">
  //     <DailyCheckList dailyCheckList={testData} />
  //   </div>
  // );
  const [data, setData] = useState([]);
  const dataId = useRef(0);

  const onCreate = (date: string, title: string) => {
    const newItem = {
      id: dataId.current,
      date,
      title
    };
    dataId.current += 1;
    setData([newItem, ...data]);
  };

  const onDelete = (targetId: number) => {
    const newDailyCheckList = data.filter((it) => it.id !== targetId);
    setData(newDailyCheckList);
  };

  return (
    <div className="App">
      <CheckListEditor onCreate={onCreate} />
      <DailyCheckList onDelete={onDelete} dailyCheckList={data} />
    </div>
  );
};

export default DailyCheck;
