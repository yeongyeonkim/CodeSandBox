import CheckItem from "./CheckItem";

const DailyCheckList = ({ onDelete, dailyCheckList }: any) => {
  return (
    <div>
      <h1> 일정 </h1>
      <div>
        {dailyCheckList.map((it: any) => {
          return (
            <div>
              {dailyCheckList.map((it: any) => {
                return <CheckItem key={it.id} {...it} onDelete={onDelete} />;
              })}
            </div>
            // <div key={it.id}>
            //   <span>
            //     {it.id}. 날짜: {it.date} 내용: {it.title}{" "}
            //   </span>
            // </div>
          );
        })}
      </div>
    </div>
  );
};

export default DailyCheckList;
