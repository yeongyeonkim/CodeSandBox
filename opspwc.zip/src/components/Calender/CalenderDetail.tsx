import React from "react";

const CalenderDetail = () => {
  return <div>달력 상세</div>;
};
export default CalenderDetail;
