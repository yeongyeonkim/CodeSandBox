export interface DaySchedule {
  id: number;
  date: string;
  title: string;
}
