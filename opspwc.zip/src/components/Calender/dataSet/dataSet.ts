import { DaySchedule } from "./DataSet.interface";

export const dayScheduleData: DaySchedule[] = [
  {
    id: 1,
    date: "2022-11-03",
    title: "title"
  },

  {
    id: 2,
    date: "2022-11-08",
    title: "title2"
  }
];
