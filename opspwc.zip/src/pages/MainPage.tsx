import React from "react";
import First from "./First";

const MainPage = () => {
  return <First />;
};

export default MainPage;
