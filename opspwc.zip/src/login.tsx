import React from "react";
import Tmp from "./pages/Tmp";

function login() {
  return (
    <div>
      <Tmp />
    </div>
  );
}

export default login;
